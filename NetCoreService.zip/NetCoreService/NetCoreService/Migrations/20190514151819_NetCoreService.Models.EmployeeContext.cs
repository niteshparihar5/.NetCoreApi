﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NetCoreService.Migrations
{
    public partial class NetCoreServiceModelsEmployeeContext : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
